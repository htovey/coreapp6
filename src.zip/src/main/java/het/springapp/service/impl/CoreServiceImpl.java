package het.springapp.service.impl;

import org.springframework.stereotype.Service;

import het.springapp.model.Note;
import het.springapp.service.CoreService;

@Service
public class CoreServiceImpl implements CoreService{

	public Note saveNote() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
 
}
